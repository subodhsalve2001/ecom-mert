import React from 'react'
import { BestSellerGrid, Carousel_mui } from '../components'


const Home = () => {
  return <>
  <Carousel_mui/>
  <BestSellerGrid/>
  </>
}

export default Home