import React from 'react'

const EmployeeRegister = () => {
  return (
    <div>EmployeeRegister</div>
  )
}

export default EmployeeRegister